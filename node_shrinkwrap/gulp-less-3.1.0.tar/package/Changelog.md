### 3.0.1
- Bumped accord version to 0.15.1 to fix #122

### 3.0.0
- Switch to using [accord](https://github.com/jenius/accord) for options parsing

### 2.0.3

- Fix less errors by using promises correctly
- Fix option merging, object.assign was used incorrectly

### 2.0.1

Revert moving the replaceExt to after sourcemaps are applied

### 2.0.0

Update to Less 2.0