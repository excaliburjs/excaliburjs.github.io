/**!
 * resolve-dep
 * http://github.com/jonschlinkert/resolve-dep
 *
 * Copyright (c) 2013, Jon Schlinkert, contributors
 * Licensed under the MIT license.
 */

module.exports = require('./lib/resolve-dep');
