---
title: 'Coffee'
description: '''
  Front matter
  '''
categories: '''
  front matter coffee coffee-script
  '''
---

# This page has coffee front matter!