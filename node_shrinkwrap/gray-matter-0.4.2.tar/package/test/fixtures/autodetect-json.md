;;; json
{
  "title": "JSON",
  "description": "Front Matter"
}
;;;

# This page has JSON front matter!