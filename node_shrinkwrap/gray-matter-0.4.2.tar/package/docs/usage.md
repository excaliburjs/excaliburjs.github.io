```js
var matter = require('gray-matter');
matter(String, Object);
```