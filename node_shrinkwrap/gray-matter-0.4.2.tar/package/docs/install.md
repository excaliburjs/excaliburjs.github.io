Install with [npm](npmjs.org)

```bash
npm i gray-matter --save
```
Install with [bower](https://github.com/bower/bower)

```bash
bower install gray-matter --save
```