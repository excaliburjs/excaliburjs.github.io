'use strict';
var cwd = require('cwd');
module.exports = require(cwd('package.json'));