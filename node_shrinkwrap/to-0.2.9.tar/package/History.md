# release 0.2.8
 * added test directory
 * any file can be loaded as yaml
 * handling full yaml spec (switched to js-yaml)
 * xml input supported
 * nested element handling for xml added
 * command line tool fixed, output of yaml beautified

# release 0.1.0
 * yaml and json loaders 
 * convert between json and yaml examples added

# release 0.0.1
 * initial repository creation
