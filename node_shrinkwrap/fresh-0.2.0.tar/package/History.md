
0.2.0 / 2013-08-11 
==================

  * fix: return false for no-cache
