# release 0.0.13
 * added isObjectEqual
 * only works nodejs > 0.8
 * added travis-ci
 * added getFileExtension
 * added isArrayEqual
 * added deepMerge
 * added getType, merge
 * added getUserHome
 * added getVersion
 * initial repository creation
