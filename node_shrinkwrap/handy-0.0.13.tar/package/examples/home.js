// print the package version

var handy = require('..');

console.log(handy.getUserHome());