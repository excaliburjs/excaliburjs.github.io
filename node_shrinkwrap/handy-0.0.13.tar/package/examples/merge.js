var handy = require('..');
var x = {a:1}, y={b:2}, z={a:4,c:5};
console.log(handy.merge(x,y,z));
