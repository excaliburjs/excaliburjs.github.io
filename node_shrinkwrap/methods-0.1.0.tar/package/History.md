
0.1.0 / 2013-10-28 
==================

 * add http.METHODS support
