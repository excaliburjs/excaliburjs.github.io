alert('Haikus are easy');
throw "hi"