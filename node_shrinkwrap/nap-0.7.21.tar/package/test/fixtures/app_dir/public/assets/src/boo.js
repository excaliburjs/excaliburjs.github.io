(function() {
  var boo;

  boo = 'bam';

}).call(this);
