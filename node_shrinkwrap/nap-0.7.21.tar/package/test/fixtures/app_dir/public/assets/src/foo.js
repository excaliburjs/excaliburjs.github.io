(function() {
  var foo;

  foo = 'bar';

}).call(this);
