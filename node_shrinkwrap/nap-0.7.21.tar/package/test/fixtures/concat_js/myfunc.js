function myfunc() {
	return 1;
}// Comment at the end of the file