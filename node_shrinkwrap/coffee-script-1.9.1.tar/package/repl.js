module.exports = require('./lib/coffee-script/repl');
