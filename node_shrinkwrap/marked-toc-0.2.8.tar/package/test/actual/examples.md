# [Examples](../fixtures/examples.md)

* [Examples](../fixtures/examples.md/#examples)
  * [Example config with [Assemble](http://assemble.io)](../fixtures/examples.md/#example-config-with-assemblehttpassembleio)
* [Usage example](../fixtures/examples.md/#usage-example)
    * [`cwd` example](../fixtures/examples.md/#cwd-example)
