# Examples

<!-- toc -->


This isn't in a code block

```
this IS in a code block
```

This isn't in a code block
