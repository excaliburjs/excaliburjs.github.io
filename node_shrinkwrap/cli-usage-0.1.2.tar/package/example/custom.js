var usage = require('../');

console.log(usage.get('# some custom markdown from string'));

console.log(usage.get('./usage.md'));