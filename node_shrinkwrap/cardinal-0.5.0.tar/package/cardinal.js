module.exports = {
    highlight: require('./lib/highlight')
  , highlightFile: require('./lib/highlightFile')
  , highlightFileSync: require('./lib/highlightFileSync')
};
