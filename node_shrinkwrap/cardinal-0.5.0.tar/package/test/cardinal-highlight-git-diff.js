
// Test Cases
//  highlightDiff('@@ -25,22 +31,47 @@ function resolveTheme (config) { }')
