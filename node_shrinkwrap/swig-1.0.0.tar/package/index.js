module.exports = require('./lib/swig');
