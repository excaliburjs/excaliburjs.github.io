--- toml
title = "autodetect-TOML"

[props]
user = "jonschlinkert"
---
Content
