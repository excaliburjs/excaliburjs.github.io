--- coffee
data =
  title: 'autodetect-coffee'
  user: 'jonschlinkert'
---
Content