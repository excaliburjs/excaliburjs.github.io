---cson
title: 'autodetect-CSON'
user: 'jonschlinkert'
---
Content