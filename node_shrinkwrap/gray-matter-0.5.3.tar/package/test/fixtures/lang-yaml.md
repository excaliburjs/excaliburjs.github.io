---
title: YAML
---

# This page has YAML front matter!
