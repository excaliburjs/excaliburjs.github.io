---json
{
  "title": "autodetect-JSON",
  "description": "Front Matter"
}
---

# This page has JSON front matter!