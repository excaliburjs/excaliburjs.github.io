~~~
title: custom-delims
foo: bar
version: 2
~~~

<span class="alert alert-info">This is an alert</span>
