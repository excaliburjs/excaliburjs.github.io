---yaml
title: autodetect-yaml
user: jonschlinkert
---
Content