---
title: autodetect-no-lang
user: jonschlinkert
---
Content