```bash
npm i -g {%= name %} --save-dev
```