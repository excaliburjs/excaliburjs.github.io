# {%= name %} {%= badge('fury') %}

> {%= description %}

_(WIP)_

## Install with [npm](npmjs.org)
{%= docs('install') %}

## Author
{%= contrib("jon") %}

## License
{%= copyright() %}
{%= license() %}

***

{%= include("footer") %}