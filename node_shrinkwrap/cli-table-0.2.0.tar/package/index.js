
module.exports = require('./lib/cli-table');
