module.exports = require('./lib/extend');

