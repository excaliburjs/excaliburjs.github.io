## 1.0.1 / 2013-04-02

  - Fix tests



## 1.0.0 / 2012-02-28

  - Add tests for the stable release



## 0.0.2 / 2012-01-11

  - Add repository to package.json



## 0.0.1 / 2012-01-10

  - Initial release
