/*jslint indent: 4*/

function someFunction() {
    var a = 5;
    console.log(a);
    process.exit(1234);
}
