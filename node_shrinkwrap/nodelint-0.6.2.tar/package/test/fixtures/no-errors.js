function someRightFunction() {
  var a = 2, b = a + 1;
  console.log(a + b);
  process.exit(777);
}
