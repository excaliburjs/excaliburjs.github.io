
0.1.0 / 2011-04-13 
==================

  * Added jQuery-ish array support

0.0.7 / 2011-03-13 
==================

  * Fixed; handle empty string and `== null` in `qs.parse()` [dmit]
    allows for convenient `qs.parse(url.parse(str).query)`

0.0.6 / 2011-02-14 
==================

  * Fixed; support for implicit arrays

0.0.4 / 2011-02-09 
==================

  * Fixed `+` as a space

0.0.3 / 2011-02-08 
==================

  * Fixed case when right-hand value contains "]"

0.0.2 / 2011-02-07 
==================

  * Fixed "=" presence in key

0.0.1 / 2011-02-07 
==================

  * Initial release