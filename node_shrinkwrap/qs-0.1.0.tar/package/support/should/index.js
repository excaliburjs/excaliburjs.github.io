
module.exports = require('./lib/should');