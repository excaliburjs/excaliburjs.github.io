module.exports = require("weak-map");
