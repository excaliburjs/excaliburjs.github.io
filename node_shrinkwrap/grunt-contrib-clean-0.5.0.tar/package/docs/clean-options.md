# Options

## force
Type: `Boolean`  
Default: false

This overrides this task from blocking deletion of folders outside current working dir (CWD). Use with caution.

## no-write
Type: `Boolean`  
Default: false

Will log messages of what would happen if the task was ran but doesn't actually delete the files.
