
var HTTP = require("./http");
var Apps = require("./http-apps");

var chain = new Apps.Chain()
.use(Apps.Time)
.use(Apps.Log)
.use(Apps.HandleHtmlFragmentResponses)
.use(Apps.HandleJsonResponses)
.use(Apps.Debug)
.use(Apps.ListDirectories)
.use(Apps.DirectoryIndex)
.use(function (next) {
    return Apps.FileTree(__dirname + "/../", {
        notFound: next
    });
})

HTTP.Server(chain.end())
.listen(8888);
console.log("Listening");

