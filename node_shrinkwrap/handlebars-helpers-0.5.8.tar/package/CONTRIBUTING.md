Please see the [Contributing to Assemble](http://assemble.io/contributing) guide for information on contributing to this project.
